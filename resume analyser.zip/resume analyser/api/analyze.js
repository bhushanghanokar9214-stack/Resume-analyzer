import formidable from 'formidable';
import fs from 'fs';
import pdfParse from 'pdf-parse';
import mammoth from 'mammoth';
import OpenAI from 'openai';

export const config = {
  api: { bodyParser: false }
};

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  const form = new formidable.IncomingForm();
  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: err.message });

    const file = files.resume;
    if (!file) return res.status(400).json({ error: 'No file uploaded' });

    let text = '';
    if (file.mimetype === 'application/pdf') {
      const dataBuffer = fs.readFileSync(file.filepath);
      const pdfData = await pdfParse(dataBuffer);
      text = pdfData.text;
    } else if (file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      const data = fs.readFileSync(file.filepath);
      const result = await mammoth.extractRawText({ buffer: data });
      text = result.value;
    } else {
      return res.status(400).json({ error: 'Unsupported file type' });
    }

    // OpenAI AI analysis
    const aiResponse = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are a resume analyzer." },
        { role: "user", content: `Analyze this resume and give a score 0-100 with suggestions:\n\n${text}` }
      ]
    });

    const suggestions = aiResponse.choices[0].message.content;

    res.status(200).json({
      score: 85, // Optional: you can parse score from suggestions
      suggestions,
      extractedText: text
    });
  });
}